# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bimatrix2xpro']

package_data = \
{'': ['*']}

install_requires = \
['PySimpleGUI>=4.30.0,<5.0.0']

entry_points = \
{'console_scripts': ['b2x = bimatrix2xpro.script:main']}

setup_kwargs = {
    'name': 'bimatrix2xpro',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'bear_montblanc',
    'author_email': '44293565+Be4rR@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
